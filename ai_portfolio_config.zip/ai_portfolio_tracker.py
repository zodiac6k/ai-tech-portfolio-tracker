import yfinance as yf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import json
import os
import warnings

warnings.filterwarnings('ignore')


class AITechPortfolioTracker:
    def __init__(self, config_file="ai_portfolio_config.json"):
        self.config_file = config_file
        self.portfolio = {}
        self.stock_data = {}
        self.load_config()

    def load_config(self):
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
                self.portfolio = config.get('portfolio', {})
        except FileNotFoundError:
            print(f"Config file {self.config_file} not found. Using empty portfolio.")

    def fetch_stock_data(self, period="1y"):
        print("Fetching stock data...")
        for symbol in self.portfolio.keys():
            try:
                ticker = yf.Ticker(symbol)
                hist = ticker.history(period=period)
                info = ticker.info
                self.stock_data[symbol] = {
                    'history': hist,
                    'info': info,
                    'current_price': hist['Close'].iloc[-1] if not hist.empty else 0
                }
                print(f"✓ {symbol}")
            except Exception as e:
                print(f"✗ {symbol} failed: {e}")
                self.stock_data[symbol] = {'history': pd.DataFrame(), 'info': {}, 'current_price': 0}
        return self.stock_data

    def calculate_metrics(self):
        metrics = {}
        total_value, total_cost = 0, 0
        rows = []
        for symbol, holding in self.portfolio.items():
            if symbol not in self.stock_data:
                continue
            current_price = self.stock_data[symbol]['current_price']
            shares = holding['shares']
            market_value = current_price * shares
            cost_basis = current_price * 0.9  # mock cost basis
            cost_value = cost_basis * shares
            gain_loss = market_value - cost_value
            gain_loss_pct = (gain_loss / cost_value * 100) if cost_value > 0 else 0
            total_value += market_value
            total_cost += cost_value
            rows.append({
                "Symbol": symbol,
                "Shares": shares,
                "Current_Price": current_price,
                "Market_Value": market_value,
                "Gain_Loss_Pct": gain_loss_pct,
                "Category": holding['category'],
                "Region": holding['region']
            })
        df = pd.DataFrame(rows)
        metrics['portfolio_df'] = df
        metrics['total_value'] = total_value
        metrics['total_cost'] = total_cost
        metrics['total_gain_loss_pct'] = (total_value - total_cost) / total_cost * 100 if total_cost else 0
        return metrics

    def analyze_ai_growth(self):
        analysis = {}
        for symbol, data in self.stock_data.items():
            hist = data['history']
            if hist.empty:
                continue
            current_price = hist['Close'].iloc[-1]
            price_6m_ago = hist['Close'].iloc[-130] if len(hist) >= 130 else hist['Close'].iloc[0]
            growth_6m = ((current_price - price_6m_ago) / price_6m_ago * 100) if price_6m_ago > 0 else 0
            analysis[symbol] = {
                "ai_relevance_score": 9.0 if symbol in ["NVDA", "TSM", "MSFT", "PLTR"] else 7.0,
                "growth_6m": growth_6m,
                "volatility": hist['Close'].pct_change().std() * np.sqrt(252) * 100
            }
        return analysis

    def export_html(self, metrics, growth_analysis):
        os.makedirs("docs/charts", exist_ok=True)

        # Top AI ranking
        df_growth = pd.DataFrame(growth_analysis).T
        df_growth["ai_relevance_score"] = pd.to_numeric(df_growth["ai_relevance_score"], errors="coerce")
        top_ai = df_growth.nlargest(5, "ai_relevance_score")[["ai_relevance_score", "growth_6m", "volatility"]]

        # Chart
        plt.figure(figsize=(10, 6))
        plt.barh(top_ai.index, top_ai["ai_relevance_score"], color="royalblue")
        plt.xlabel("AI Relevance Score")
        plt.title("Top AI Growth Potential")
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig("docs/charts/ai_portfolio_analysis.png")
        plt.close()

        # HTML page
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>AI Tech Portfolio Tracker</title>
            <style>
                body {{ font-family: Arial; padding: 20px; background: #f8f9fa; }}
                table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: center; }}
                th {{ background-color: #2c3e50; color: white; }}
                tr:nth-child(even) {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h1>AI Tech Portfolio Tracker</h1>
            <p>Last Updated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
            <p><a href="https://zodiac6k.github.io/ESG/">← Back to ESG Dashboard</a></p>
            {metrics['portfolio_df'].to_html(index=False)}
            <img src="charts/ai_portfolio_analysis.png" alt="AI Portfolio Chart">
        </body>
        </html>
        """
        with open("docs/ai.html", "w", encoding="utf-8") as f:
            f.write(html_content)
        print("AI dashboard generated: docs/ai.html")

    def run_full(self):
        self.fetch_stock_data()
        metrics = self.calculate_metrics()
        growth = self.analyze_ai_growth()
        self.export_html(metrics, growth)


if __name__ == "__main__":
    # Skip interactive mode in CI
    if os.environ.get("GITHUB_ACTIONS") == "true":
        tracker = AITechPortfolioTracker()
        tracker.run_full()
    else:
        tracker = AITechPortfolioTracker()
        tracker.run_full()
